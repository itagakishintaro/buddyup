/**
 * Responds to any HTTP request.
 *
 * @param {!Object} req HTTP request context.
 * @param {!Object} res HTTP response context.
 */
exports.syntax = (req, res) => {
  // Imports the Google Cloud client library
  const language = require('@google-cloud/language');

  // Creates a client
  const client = new language.LanguageServiceClient();

  console.log('Request Body: ', req.body);
  console.log('Request Message: ', JSON.parse(req.body).message );
  let text = JSON.parse(req.body).message;
  // Prepares a document, representing the provided text
  const document = {
    content: text,
    type: 'PLAIN_TEXT',
  };

  // Detects syntax in the document
  client
    .analyzeSyntax({document: document})
    .then(results => {
      console.log('RESULTS:', results);
      res.header( 'Access-Control-Allow-Origin', '*' );
      res.header('Content-Type', 'application/json; charset=utf-8');
      res.send(results);
    })
    .catch(err => {
      console.error('ERROR:', err);
    });
};